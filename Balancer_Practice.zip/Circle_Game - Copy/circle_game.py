import pygame
import random
import string
import math
import os

# 1. Initialize Pygame and Mixer
pygame.init()
# Adjusted mixer settings for better compatibility
pygame.mixer.init(frequency=22050, size=-16, channels=2, buffer=512)

# --- Calm Color Palette ---
BACKGROUND = (24, 28, 52)      # Dark Navy Blue
TEXT_COLOR = (220, 220, 240)    # Soft Off-White
PRIMARY_BUBBLE = (255, 137, 164, 150) # Pink, with alpha for transparency
SECONDARY_BUBBLE = (136, 212, 224, 150) # Blue, with alpha
ACCURACY_GOOD = (137, 255, 172) # Soft Green
ACCURACY_WARN = (255, 220, 137) # Soft Yellow

# --- Game Constants ---
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
FPS = 60
MIN_ACCURACY_THRESHOLD = 60
# Define a threshold for successful hits to be more forgiving
HIT_THRESHOLD = 30 

# --- Game Window ---
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Calm Circles")
# A separate surface for drawing transparent bubbles
bubble_surface = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)

# --- Assets Loading (Font, Music, Sound) ---
# Use a more reliable way to find the font file
try:
    font_path = os.path.join(os.path.dirname(__file__), 'font.ttf')
    main_font = pygame.font.Font(font_path, 60)
    ui_font = pygame.font.Font(font_path, 35)
except FileNotFoundError:
    print("Warning: 'font.ttf' not found. Falling back to default font.")
    main_font = pygame.font.SysFont('Arial', 50, bold=True)
    ui_font = pygame.font.SysFont('Arial', 30)

# Use a more reliable way to find the music file
try:
    music_path = os.path.join(os.path.dirname(__file__), 'music.mp3')
    pygame.mixer.music.load(music_path)
    pygame.mixer.music.set_volume(0.5) # Set music volume to 50%
    pygame.mixer.music.play(-1) # -1 means loop forever
except pygame.error:
    print("Warning: 'music.mp3' not found. Music will not play.")

# Use a more reliable way to find the sound files
try:
    success_sound_path = os.path.join(os.path.dirname(__file__), 'pop.wav')
    fail_sound_path = os.path.join(os.path.dirname(__file__), 'miss.wav')
    success_sound = pygame.mixer.Sound(success_sound_path)
    fail_sound = pygame.mixer.Sound(fail_sound_path)
    success_sound.set_volume(0.6)
    fail_sound.set_volume(0.4)
except pygame.error:
    print("Warning: Sound effect files not found. Game will be silent.")
    # Create silent placeholder sounds so the game doesn't crash
    success_sound = pygame.mixer.Sound(buffer=b'\x00' * 1024)
    fail_sound = pygame.mixer.Sound(buffer=b'\x00' * 1024)

clock = pygame.time.Clock()

# --- Bubbly Particle System ---
particles = []
class Particle:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.radius = random.randint(10, 25)
        self.angle = random.uniform(0, 2 * math.pi)
        self.speed = random.uniform(0.5, 2)
        self.vx = math.cos(self.angle) * self.speed
        self.vy = math.sin(self.angle) * self.speed
        self.life = self.radius * 2 # Bubbles last longer
        self.start_life = self.life
        self.color = random.choice([PRIMARY_BUBBLE, SECONDARY_BUBBLE])

    def update(self):
        self.x += self.vx
        self.y += self.vy
        self.vy -= 0.02 # Gently float up
        self.life -= 1
        return self.life > 0

    def draw(self, surface):
        # Fade out as life decreases
        alpha = max(0, int(255 * (self.life / self.start_life)))
        # Draw a semi-transparent bubble
        temp_surf = pygame.Surface((self.radius * 2, self.radius * 2), pygame.SRCALPHA)
        # Use BLEND_RGBA_ADD for a more bubbly effect
        pygame.draw.circle(temp_surf, (*self.color[:3], int(alpha * 0.5)), (self.radius, self.radius), self.radius)
        surface.blit(temp_surf, (int(self.x - self.radius), int(self.y - self.radius)), special_flags=pygame.BLEND_RGBA_ADD)

def create_particles(x, y, count=15):
    for _ in range(count):
        particles.append(Particle(x, y))

# --- Game State ---
def start_new_game():
    return {
        'score': 0, 'speed': 0.6, 'successful_hits': 0, 'total_attempts': 0,
        'accuracy': 100.0, 'game_over': False, 'active_game': True
    }

def new_round():
    letter = random.choice(string.ascii_uppercase)
    key = getattr(pygame, f"K_{letter.lower()}")
    x = random.randint(150, SCREEN_WIDTH - 150)
    y = random.randint(150, SCREEN_HEIGHT - 150)
    return letter, key, x, y, 140, 60 # letter, key, x, y, outer_r, inner_r

# --- Initial Game Setup ---
game_state = start_new_game()
current_letter, current_key, letter_x, letter_y, outer_radius, inner_radius = new_round()
hit_animation = {'timer': 0, 'radius': 0, 'pos': (0,0)}

# --- Main Game Loop ---
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        
        if event.type == pygame.KEYDOWN:
            if game_state['game_over']:
                game_state = start_new_game()
                current_letter, current_key, letter_x, letter_y, outer_radius, inner_radius = new_round()
            elif game_state['active_game']:
                game_state['total_attempts'] += 1
                if event.key == current_key and abs(outer_radius - inner_radius) < HIT_THRESHOLD:
                    # SUCCESS
                    game_state['score'] += 1
                    game_state['successful_hits'] += 1
                    game_state['speed'] += 0.05 # Slower scaling
                    success_sound.play()
                    create_particles(letter_x, letter_y)
                    # Start the success animation
                    hit_animation = {'timer': 15, 'radius': inner_radius, 'pos': (letter_x, letter_y)}
                else:
                    # FAILURE
                    fail_sound.play()
                
                current_letter, current_key, letter_x, letter_y, outer_radius, inner_radius = new_round()

    # --- Game Logic Update ---
    if not game_state['game_over']:
        outer_radius -= game_state['speed']
        
        if outer_radius < inner_radius: # Missed
            game_state['total_attempts'] += 1
            fail_sound.play()
            current_letter, current_key, letter_x, letter_y, outer_radius, inner_radius = new_round()
        
        if game_state['total_attempts'] > 0:
            game_state['accuracy'] = (game_state['successful_hits'] / game_state['total_attempts']) * 100
        
        # Delay the game over to allow the player to see their final accuracy
        if game_state['total_attempts'] > 5 and game_state['accuracy'] < MIN_ACCURACY_THRESHOLD:
            game_state['active_game'] = False
            game_state['game_over'] = True


    # --- Drawing ---
    screen.fill(BACKGROUND)
    bubble_surface.fill((0, 0, 0, 0)) # Clear the bubble surface

    # Update and draw particles
    particles = [p for p in particles if p.update()]
    for p in particles: p.draw(bubble_surface)

    if game_state['game_over']:
        # Game Over screen
        msg_text = main_font.render("So close!", True, TEXT_COLOR)
        score_text = ui_font.render(f"Final Score: {game_state['score']}", True, TEXT_COLOR)
        restart_text = ui_font.render("Press any key to relax again", True, TEXT_COLOR)
        
        screen.blit(msg_text, (SCREEN_WIDTH // 2 - msg_text.get_width() // 2, SCREEN_HEIGHT // 2 - 100))
        screen.blit(score_text, (SCREEN_WIDTH // 2 - score_text.get_width() // 2, SCREEN_HEIGHT // 2))
        screen.blit(restart_text, (SCREEN_WIDTH // 2 - restart_text.get_width() // 2, SCREEN_HEIGHT // 2 + 50))
    elif game_state['active_game']:
        # Draw game elements to the transparent surface
        pygame.draw.circle(bubble_surface, PRIMARY_BUBBLE, (letter_x, letter_y), int(outer_radius))
        pygame.draw.circle(bubble_surface, SECONDARY_BUBBLE, (letter_x, letter_y), inner_radius)


        # Draw hit animation
        if hit_animation['timer'] > 0:
            alpha = int(255 * (hit_animation['timer'] / 15))
            radius = hit_animation['radius'] + (15 - hit_animation['timer']) * 2
            pygame.draw.circle(bubble_surface, (*ACCURACY_GOOD[:3], alpha), hit_animation['pos'], int(radius), 5)
            hit_animation['timer'] -= 1

        # Blit the transparent surface onto the main screen
        screen.blit(bubble_surface, (0, 0))

        # Draw UI Text on top
        letter_surface = main_font.render(current_letter, True, TEXT_COLOR)
        screen.blit(letter_surface, letter_surface.get_rect(center=(letter_x, letter_y)))

        score_display = ui_font.render(f"Score: {game_state['score']}", True, TEXT_COLOR)
        acc_color = ACCURACY_GOOD if game_state['accuracy'] >= MIN_ACCURACY_THRESHOLD else ACCURACY_WARN
        accuracy_display = ui_font.render(f"Accuracy: {game_state['accuracy']:.1f}%", True, acc_color)
        
        screen.blit(score_display, (15, 10))
        screen.blit(accuracy_display, (15, 50))
    
    pygame.display.flip()
    clock.tick(FPS)

pygame.quit()